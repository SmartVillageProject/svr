package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MedicalFacilities extends AppCompatActivity {
    EditText mfac, alhos, ayhos, unhos, homhos, aldisp, aydisp, undisp, homdisp, matchw, mathom, chw,
            hc, phc, phsc, fwc, tbc, nhom, rpmp, smp, chwr, omfac;
    RadioGroup rg1, rg2, rg3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_facilities);

        mfac = (EditText) findViewById(R.id.med_fac);
        alhos = (EditText) findViewById(R.id.allo_hos);
        ayhos = (EditText) findViewById(R.id.ayu_hos);
        unhos = (EditText) findViewById(R.id.una_hos);
        homhos = (EditText) findViewById(R.id.homo_hos);
        aldisp = (EditText) findViewById(R.id.allo_disp);
        aydisp = (EditText) findViewById(R.id.ayu_disp);
        undisp = (EditText) findViewById(R.id.una_disp);
        homdisp = (EditText) findViewById(R.id.homo_disp);
        matchw = (EditText) findViewById(R.id.mat_wel);
        mathom = (EditText) findViewById(R.id.mat_home);
        chw = (EditText) findViewById(R.id.child_wel);
        hc = (EditText) findViewById(R.id.hea_cen);
        phc = (EditText) findViewById(R.id.pri_hea);
        phsc = (EditText) findViewById(R.id.pri_sub);
        fwc = (EditText) findViewById(R.id.fam_wel);
        tbc = (EditText) findViewById(R.id.tb_clinic);
        nhom = (EditText) findViewById(R.id.nur_hom);
        rpmp = (EditText) findViewById(R.id.med_prac);
        smp = (EditText) findViewById(R.id.sub_med_prac);
        chwr = (EditText) findViewById(R.id.com_hea);
        omfac = (EditText) findViewById(R.id.other_med_fac);
        rg1 = (RadioGroup) findViewById(R.id.allopa);
        rg2 = (RadioGroup) findViewById(R.id.mater_wel);
        rg3 = (RadioGroup) findViewById(R.id.prihea);




    }

    public void gotoList(View view) {
        long med_fac, allo_hos, ayu_hos, una_hos, homo_hos, allo_disp, ayu_disp, una_disp, homo_disp,
                mat_wel, mat_home, child_wel, hea_cen, pri_hea, pri_sub, fam_wel, tb_clinic, nur_hom,
                med_prac, sub_med_prac, com_hea, other_med_fac;
        med_fac = Long.parseLong("0" + mfac.getText().toString());
        allo_hos = Long.parseLong("0" + alhos.getText().toString());
        ayu_hos = Long.parseLong("0" + ayhos.getText().toString());
        una_hos = Long.parseLong("0" + unhos.getText().toString());
        homo_hos = Long.parseLong("0" + homhos.getText().toString());
        allo_disp = Long.parseLong("0" + aldisp.getText().toString());
        ayu_disp = Long.parseLong("0" + aydisp.getText().toString());
        una_disp = Long.parseLong("0" + undisp.getText().toString());
        homo_disp = Long.parseLong("0" + homdisp.getText().toString());
        mat_wel = Long.parseLong("0" + matchw.getText().toString());
        mat_home = Long.parseLong("0" + mathom.getText().toString());
        child_wel = Long.parseLong("0" + chw.getText().toString());
        hea_cen = Long.parseLong("0" + hc.getText().toString());
        pri_hea = Long.parseLong("0" + phc.getText().toString());
        pri_sub = Long.parseLong("0" + phsc.getText().toString());
        fam_wel = Long.parseLong("0" + fwc.getText().toString());
        tb_clinic = Long.parseLong("0" + tbc.getText().toString());
        nur_hom = Long.parseLong("0" + nhom.getText().toString());
        med_prac = Long.parseLong("0" + rpmp.getText().toString());
        sub_med_prac = Long.parseLong("0" + smp.getText().toString());
        com_hea = Long.parseLong("0" + chwr.getText().toString());
        other_med_fac = Long.parseLong("0" + omfac.getText().toString());

        int chosenid1 = rg1.getCheckedRadioButtonId();
        switch (chosenid1) {
            case R.id.all_yes:
                break;
            case R.id.all_no:
                break;

        }
        int chosenid2 = rg2.getCheckedRadioButtonId();
        switch (chosenid2) {
            case R.id.mat_yes:
                break;
            case R.id.mat_no:
                break;

        }
        int chosenid3 = rg3.getCheckedRadioButtonId();
        switch (chosenid3) {
            case R.id.pri_yes:
                break;
            case R.id.pri_no:
                break;

        }
        Intent i = new Intent(this, ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        mfac.setText("");
        alhos.setText("");
        ayhos.setText("");
        unhos.setText("");
        homhos.setText("");
        aldisp.setText("");
        aydisp.setText("");
        undisp.setText("");
        homdisp.setText("");
        chw.setText("");
        hc.setText("");
        phc.setText("");
        phsc.setText("");
        fwc.setText("");
        tbc.setText("");
        nhom.setText("");
        rpmp.setText("");
        smp.setText("");
        omfac.setText("");
        rg1.clearCheck();
        rg2.clearCheck();
        rg3.clearCheck();
    }

    public void goBack(View view) {
        Intent i = new Intent(this, ListOfDomains.class);
        startActivity(i);

    }
}