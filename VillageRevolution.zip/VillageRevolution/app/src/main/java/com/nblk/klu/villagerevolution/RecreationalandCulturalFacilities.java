package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class RecreationalandCulturalFacilities extends AppCompatActivity {
    RadioGroup r,r1,r2,r3;
    EditText hhold,cinevideo,sports,sta_audi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recreationaland_cultural_facilities);
        hhold=findViewById(R.id.hhc);
        cinevideo=findViewById(R.id.chvh);
        sports=findViewById(R.id.sc);
        sta_audi=findViewById(R.id.sa);
        r=findViewById(R.id.trg);
        r1=findViewById(R.id.crg);
        r2=findViewById(R.id.srg);
        r3=findViewById(R.id.sarg);

    }

    public void gotoList(View view) {
        long household,cine_video,sport_club,sport_club_ava;
        int chooseid,chooseid1,chooseid2,chooseid3;
        household=Long.parseLong("0"+hhold.getText().toString());
        cine_video=Long.parseLong("0"+cinevideo.getText().toString());
        sport_club=Long.parseLong("0"+sports.getText().toString());
        sport_club_ava=Long.parseLong("0"+sta_audi.getText().toString());
        chooseid=r.getCheckedRadioButtonId();
        chooseid1=r1.getCheckedRadioButtonId();
        chooseid2=r2.getCheckedRadioButtonId();
        chooseid3=r3.getCheckedRadioButtonId();
        switch(chooseid){
            case R.id.tyes:
                break;
            case R.id.tno:
                break;
        }
        switch (chooseid1){
            case R.id.cyes:
                break;
            case R.id.cno:
                break;
        }
        switch(chooseid2){
            case R.id.syes:
                break;
            case R.id.sno:
                break;
        }
        switch(chooseid3){
            case R.id.sayes:
                break;
            case R.id.sano:
                break;
        }
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);
    }

    public void resetAll(View view) {
        hhold.setText("");
        cinevideo.setText("");
        sports.setText("");
        sta_audi.setText("");
        r.clearCheck();
        r1.clearCheck();
        r2.clearCheck();
        r3.clearCheck();
    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }
}