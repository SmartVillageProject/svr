package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class DrinkingWaterFacilities extends AppCompatActivity {
    EditText sfwtr,tapwtr,wllwtr,tnkwtr,twell,hpump,rvrwtr,lkwtr,sprngwtr,cnlwtr,othwtr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinking_water_facilities);
        sfwtr=(EditText)findViewById(R.id.safewater);
        tapwtr=(EditText)findViewById(R.id.tapwater);
        wllwtr=(EditText)findViewById(R.id.wellwater);
        tnkwtr=(EditText)findViewById(R.id.tankwater);
        twell=(EditText)findViewById(R.id.tubewell);
        hpump=(EditText)findViewById(R.id.handpump);
        rvrwtr=(EditText)findViewById(R.id.riverwater);
        lkwtr=(EditText)findViewById(R.id.lakewater);
        sprngwtr=(EditText)findViewById(R.id.springwater);
        cnlwtr=(EditText)findViewById(R.id.canalwater);
        othwtr=(EditText)findViewById(R.id.otherwater);
    }

    public void gotoList(View view) {
        long safewater,tapwater,wellwater,tankwater,tubewell,handpump,riverwater,lakewater,springwater,canalwater,otherwater;
        safewater=Long.parseLong("0"+sfwtr.getText().toString());
        tapwater=Long.parseLong("0"+tapwtr.getText().toString());
        wellwater=Long.parseLong("0"+wllwtr.getText().toString());
        tankwater=Long.parseLong("0"+tnkwtr.getText().toString());
        tubewell=Long.parseLong("0"+twell.getText().toString());
        handpump=Long.parseLong("0"+hpump.getText().toString());
        riverwater=Long.parseLong("0"+rvrwtr.getText().toString());
        lakewater=Long.parseLong("0"+lkwtr.getText().toString());
        springwater=Long.parseLong("0"+sprngwtr.getText().toString());
        canalwater=Long.parseLong("0"+cnlwtr.getText().toString());
        otherwater=Long.parseLong("0"+othwtr.getText().toString());
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        sfwtr.setText("");
        tapwtr.setText("");
        wllwtr.setText("");
        tnkwtr.setText("");
        twell.setText("");
        hpump.setText("");
        rvrwtr.setText("");
        lkwtr.setText("");
        sprngwtr.setText("");
        cnlwtr.setText("");
        othwtr.setText("");
    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}
