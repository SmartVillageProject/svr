package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class NewsPaperOrMagazine extends AppCompatActivity{

    RadioGroup newsmagz,newss,magz;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_paper_or_magazine);

        newsmagz=findViewById(R.id.newsmag);
        newss=findViewById(R.id.news);
        magz=findViewById(R.id.mag);


    }
    public void gotoList(View view) {
        int op1,op2,op3;

        op1=newsmagz.getCheckedRadioButtonId();
        op2=newss.getCheckedRadioButtonId();
        op3=magz.getCheckedRadioButtonId();
        switch (op1){
            case R.id.newmagyes:
                break;
            case R.id.newmagno:
                break;
        }
        switch (op2){
            case R.id.newyes:
                break;
            case R.id.newno:
                break;
        }
        switch (op3){
            case R.id.magyes:
                break;
            case R.id.magno:
                break;
        }

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {

        newsmagz.clearCheck();
        newss.clearCheck();
        magz.clearCheck();
    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }


}
