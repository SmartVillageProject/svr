package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.List;

public class AreaDetails extends AppCompatActivity {

    EditText varea,hhold,hsize,puccahouse,kutchhouse,mixedhouse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_details);

        varea=(EditText)findViewById(R.id.villagearea);
        hhold=(EditText)findViewById(R.id.household);
        hsize=(EditText)findViewById(R.id.housesize);
        puccahouse=(EditText)findViewById(R.id.pucca);
        kutchhouse=(EditText)findViewById(R.id.kutcha);
        mixedhouse=(EditText)findViewById(R.id.mixed);

    }

    public void gotoList(View view) {
        Double villagearea,housesize;
        Long household,pucca,kutcha,mixed;
        villagearea=Double.parseDouble("0"+varea.getText().toString());
        household=Long.parseLong("0"+hhold.getText().toString());
        housesize=Double.parseDouble("0"+hsize.getText().toString());
        pucca=Long.parseLong("0"+puccahouse.getText().toString());
        kutcha=Long.parseLong("0"+kutchhouse.getText().toString());
        mixed=Long.parseLong("0"+mixedhouse.getText().toString());

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);
    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        varea.setText("");
        hhold.setText("");
        hsize.setText("");
        puccahouse.setText("");
        kutchhouse.setText("");
        mixedhouse.setText("");
    }
}