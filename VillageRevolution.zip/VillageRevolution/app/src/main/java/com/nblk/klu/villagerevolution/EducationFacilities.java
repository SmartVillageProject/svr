package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class EducationFacilities extends AppCompatActivity {
    EditText cattend,sgchild,sprimary,disnprimary,msch,disnmsch,secsch,disnsecsch,col,sssch,adlcls,
            colavrng,indschl,tsch,oedsch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education_facilities);

        cattend=(EditText)findViewById(R.id.childatten);
        sgchild=(EditText)findViewById(R.id.schoolgoing);
        sprimary=(EditText)findViewById(R.id.schprimary);
        disnprimary=(EditText)findViewById(R.id.distschpri);
        msch=(EditText)findViewById(R.id.schmid);
        disnmsch=(EditText)findViewById(R.id.distschmid);
        secsch=(EditText)findViewById(R.id.schsec);
        disnsecsch=(EditText)findViewById(R.id.distschsec);
        col=(EditText)findViewById(R.id.clg);
        sssch=(EditText)findViewById(R.id.srsecsch);
        adlcls=(EditText)findViewById(R.id.adultlit);
        colavrng=(EditText)findViewById(R.id.clgrange);
        indschl=(EditText)findViewById(R.id.indsch);
        tsch=(EditText)findViewById(R.id.traisch);
        oedsch=(EditText)findViewById(R.id.edusch);


    }

    public void gotoList(View view) {
        long childatten,schoolgoing,schprimary,schmid,schsec,
                clg,srsecsch,adultlit,clgrange,indsch,traisch,edusch;
        Double distschmid,distschpri,distschsec;
        childatten=Long.parseLong("0"+cattend.getText().toString());
        schoolgoing=Long.parseLong("0"+sgchild.getText().toString());
        schprimary=Long.parseLong("0"+sprimary.getText().toString());
        distschpri=Double.parseDouble("0"+disnprimary.getText().toString());
        schmid=Long.parseLong("0"+msch.getText().toString());
        distschmid=Double.parseDouble("0"+disnmsch.getText().toString());
        schsec=Long.parseLong("0"+secsch.getText().toString());
        distschsec=Double.parseDouble("0"+disnsecsch.getText().toString());
        clg=Long.parseLong("0"+col.getText().toString());
        srsecsch=Long.parseLong("0"+sssch.getText().toString());
        adultlit=Long.parseLong("0"+adlcls.getText().toString());
        clgrange=Long.parseLong("0"+colavrng.getText().toString());
        indsch=Long.parseLong("0"+indschl.getText().toString());
        traisch=Long.parseLong("0"+tsch.getText().toString());
        edusch=Long.parseLong("0"+oedsch.getText().toString());

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        cattend.setText("");
        sgchild.setText("");
        sprimary.setText("");
        disnprimary.setText("");
        msch.setText("");
        disnmsch.setText("");
        secsch.setText("");
        disnsecsch.setText("");
        col.setText("");
        sssch.setText("");
        adlcls.setText("");
        colavrng.setText("");
        indschl.setText("");
        tsch.setText("");
        oedsch.setText("");

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}