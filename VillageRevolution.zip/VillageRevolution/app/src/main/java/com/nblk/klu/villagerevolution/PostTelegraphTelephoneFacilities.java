package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class PostTelegraphTelephoneFacilities extends AppCompatActivity {
    EditText pstoff,tele,pstndtele,tel;
    RadioGroup rg5,rg6;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_telegraph_telephone_facilities);
        pstoff=(EditText)findViewById(R.id.postoff);
        tele=(EditText)findViewById(R.id.telegr);
        pstndtele=(EditText)findViewById(R.id.postandteleg);
        tel=(EditText)findViewById(R.id.telep);
        rg5=(RadioGroup)findViewById(R.id.radioGroup5);
        rg6=(RadioGroup)findViewById(R.id.radioGroup6);
    }

    public void gotoList(View view) {
        long  postoff,telegr,postandteleg,telep;
        postoff=Long.parseLong("0"+pstoff.getText().toString());
        telegr=Long.parseLong("0"+tele.getText().toString());
        postandteleg=Long.parseLong("0"+pstndtele.getText().toString());
        telep=Long.parseLong("0"+tel.getText().toString());
        int choosenId=rg5.getCheckedRadioButtonId();
        switch(choosenId)
        {
            case R.id.pttavailyes:
                break;
            case R.id.pttavailno:
                break;
        }
        int choosenId1=rg6.getCheckedRadioButtonId();
        switch(choosenId1)
        {
            case R.id.availinteyes:
                break;
            case R.id.availinteno:
                break;
        }
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        pstoff.setText("");
        tele.setText("");
        pstndtele.setText("");
        tel.setText("");
        rg5.clearCheck();
        rg6.clearCheck();


    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}