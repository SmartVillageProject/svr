package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class IncomeAndExpenditureOfTheVillage extends AppCompatActivity {

    EditText inc,exp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income_and_expenditure_of_the_village);

        inc=findViewById(R.id.income);
        exp=findViewById(R.id.expenditure);

    }
    public void gotoList(View view) {
        double income,expendiiture;

        income=Double.parseDouble("0"+inc.getText().toString());
        expendiiture=Double.parseDouble("0"+exp.getText().toString());

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        inc.setText("");
        exp.setText("");
    }
}
