package com.nblk.klu.villagerevolution;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListOfDomains extends ListActivity {

    String ac[]={"AreaDetails","PopulationData","EducationFacilities","MedicalFacilities", "DrinkingWaterFacilities",
            "PostTelegraphTelephoneFacilities","CommunicationFacilities","Bankingfacilities","CreditSocieties",
            "RecreationalandCulturalFacilities","ApproachtoVillage","PowerSupply","NewsPaperOrMagazine",
            "MostImportantCommoditiesManufactured","AgricultureSurvey","FarmMachineryAndEquipments"};
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_domains);

        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,ac);
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        try{
            String string="com.nblk.klu.villagerevolution."+ac[position];
            Class c=Class.forName(string);
            Intent i=new Intent(this,c);
            startActivity(i);
        }
        catch (Exception e){

        }
    }
}
