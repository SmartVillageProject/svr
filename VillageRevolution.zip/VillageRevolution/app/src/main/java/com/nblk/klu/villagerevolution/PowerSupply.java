package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class PowerSupply extends AppCompatActivity {
    EditText powsupp,busi_con,no_street,comm_esta;
    RadioGroup r,r1,r2,r3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_power_supply);
        powsupp=findViewById(R.id.pow_sup);
        busi_con=findViewById(R.id.busi_conn);
        no_street=findViewById(R.id.num_street);
        comm_esta=findViewById(R.id.com_esta);
        r=findViewById(R.id.elec_dom);
        r1=findViewById(R.id.elec_agri);
        r2=findViewById(R.id.elec_other);
        r3=findViewById(R.id.elec_house);

    }
    public void gotoList(View view) {
        long power_supply,business_con,nos_street,co_esta;
        int chooseid,chooseid1,chooseid2,chooseid3;
        power_supply= Long.parseLong("0"+powsupp.getText().toString());
        business_con=Long.parseLong("0"+busi_con.getText().toString());
        nos_street=Long.parseLong("0"+no_street.getText().toString());
        co_esta=Long.parseLong("0"+comm_esta.getText().toString());
        chooseid=r.getCheckedRadioButtonId();
        chooseid1=r1.getCheckedRadioButtonId();
        chooseid2=r2.getCheckedRadioButtonId();
        chooseid3=r3.getCheckedRadioButtonId();
        switch (chooseid){
            case R.id.elec_dom_yes:
                break;
            case R.id.elec_dom_no:
                break;
        }
        switch (chooseid1){
            case R.id.elec_agri_yes:
                break;
            case R.id.elec_agri_no:
                break;

        }
        switch (chooseid2){
            case R.id.elec_other_yes:
                break;
            case R.id.elec_other_no:
                break;
        }
        switch (chooseid3) {
            case R.id.elec_house_yes:
                break;
            case R.id.elec_house_no:
                break;
        }
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        powsupp.setText("");
        busi_con.setText("");
        no_street.setText("");
        comm_esta.setText("");
        r.clearCheck();
        r1.clearCheck();
        r2.clearCheck();
        r3.clearCheck();
    }
}
