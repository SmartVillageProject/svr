package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class Bankingfacilities extends AppCompatActivity {
    EditText cmbnk,cpbnk;
    RadioGroup cmbg,rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bankingfacilities);
        cmbnk=(EditText)findViewById(R.id.combank);
        cpbnk=(EditText)findViewById(R.id.coopbank);
        cmbg=(RadioGroup)findViewById(R.id.combankg);
        rg=(RadioGroup)findViewById(R.id.radioGroup);
    }
    public void gotoList(View view) {
        long combank,coopbank;
        combank=Long.parseLong("0"+cmbnk.getText().toString());
        coopbank=Long.parseLong("0"+cpbnk.getText().toString());
        int choosenId=cmbg.getCheckedRadioButtonId();
        switch(choosenId)
        {
            case R.id.combankyes:
                break;
            case R.id.combankno:
                break;
        }
        int choosenId1=rg.getCheckedRadioButtonId();
        switch(choosenId1)
        {
            case R.id.coopyes:
                break;
            case R.id.coopno:
                break;
        }
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        cmbnk.setText("");
        cpbnk.setText("");
        rg.clearCheck();
        cmbg.clearCheck();


    }
}