package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AgricultureSurvey extends AppCompatActivity {

EditText foland,plland,gocanals,pvcanals,wellw,welle,twoe,
        twe,tank,river,lake,wfs,others,tias,uias,cws,anafculs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agriculture_survey);

        foland=findViewById(R.id.fland);
        plland=findViewById(R.id.pland);
        gocanals=findViewById(R.id.govcanals);
        pvcanals=findViewById(R.id.pvtcanals);
        wellw=findViewById(R.id.wellwoe);
        welle=findViewById(R.id.wellwe);
        twoe=findViewById(R.id.twwoe);
        twe=findViewById(R.id.twwe);
        tank=findViewById(R.id.tanks);
        river=findViewById(R.id.rivers);
        lake=findViewById(R.id.lakes);
        wfs=findViewById(R.id.wf);
        others=findViewById(R.id.other);
        tias=findViewById(R.id.tia);
        uias=findViewById(R.id.uia);
        cws=findViewById(R.id.cw);
        anafculs=findViewById(R.id.anafcul);


    }
    public void gotoList(View view) {
        double fland,pland,other,tia,uia,cw=0,anafcul;
        long govcanals,pvtcanals,wellwoe,wellwe,twwoe,twwe,tanks,rivers,lakes,wf;
        //resetAll(view);
        fland=Double.parseDouble("0"+foland.getText().toString());
        pland=Double.parseDouble("0"+plland.getText().toString());
        govcanals=Long.parseLong("0"+gocanals.getText().toString());
        pvtcanals=Long.parseLong("0"+pvcanals.getText().toString());
        wellwoe=Long.parseLong("0"+wellw.getText().toString());
        wellwe=Long.parseLong("0"+welle.getText().toString());
        twwoe=Long.parseLong("0"+twoe.getText().toString());
        twwe=Long.parseLong("0"+twe.getText().toString());
        tanks=Long.parseLong("0"+tank.getText().toString());
        rivers=Long.parseLong("0"+river.getText().toString());
        lakes=Long.parseLong("0"+lake.getText().toString());
        wf=Long.parseLong("0"+wfs.getText().toString());
        other=Double.parseDouble("0"+others.getText().toString());
        tia=Double.parseDouble("0"+tias.getText().toString());
        uia=Double.parseDouble("0"+uias.getText().toString());
        cw=Double.parseDouble("0"+cws.getText().toString());
        anafcul=Double.parseDouble("0"+anafculs.getText().toString());


        
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        foland.setText("");
        plland.setText("");
        gocanals.setText("");
        pvcanals.setText("");
        wellw.setText("");
        welle.setText("");
        twoe.setText("");
        twe.setText("");
        tank.setText("");
        river.setText("");
        lake.setText("");
        wfs.setText("");
        others.setText("");
        tias.setText("");
        uias.setText("");
        cws.setText("");
        anafculs.setText("");

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}
