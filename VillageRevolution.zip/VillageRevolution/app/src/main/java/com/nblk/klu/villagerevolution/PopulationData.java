package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class PopulationData extends AppCompatActivity {

    EditText tp,tm,tf,scp,scm,scf,stp,stm,stf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_population_data);

        tp=findViewById(R.id.person);
        tm=findViewById(R.id.male);
        tf=findViewById(R.id.female);
        scp=findViewById(R.id.scperson);
        scm=findViewById(R.id.scmale);
        scf=findViewById(R.id.scfemale);
        stp=findViewById(R.id.stperson);
        stm=findViewById(R.id.stmale);
        stf=findViewById(R.id.stfemale);

    }

    public void gotoList(View view) {
        int person,male,female,scperson,scmale,scfemale,stperson,stmale,stfemale;

        person=Integer.parseInt(tp.getText().toString());
        male=Integer.parseInt(tm.getText().toString());
        female=Integer.parseInt(tp.getText().toString());
        scperson=Integer.parseInt(scp.getText().toString());
        scmale=Integer.parseInt(scm.getText().toString());
        scfemale=Integer.parseInt(scf.getText().toString());
        stperson=Integer.parseInt(stp.getText().toString());
        stmale=Integer.parseInt(stm.getText().toString());
        stfemale=Integer.parseInt(stf.getText().toString());

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {

    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}
